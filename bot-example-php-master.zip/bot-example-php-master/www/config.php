<?php

define('BOT_BASE_DIRECTORY', '/var/www');
define('BOT_LOGS_DIRECTORY', BOT_BASE_DIRECTORY.'/logs');
define('BOT_IMAGES_DIRECTORY', BOT_BASE_DIRECTORY.'/static');
define('BOT_AUDIO_DIRECTORY', BOT_BASE_DIRECTORY.'/audio');

define('CALLBACK_API_CONFIRMATION_TOKEN', 'bb112c41'); //Строка для подтверждения адреса сервера из настроек Callback API
define('VK_API_ACCESS_TOKEN', '016cb55230eb83e34f620389s149345d975bc12e2fb6f30e0a833a51d345d0d123c3dc0abc1c864036sdf989fb8345'); //Ключ доступа сообщества
define('YANDEX_API_KEY', '30e3213440-61233-1294-b3415-471212369886'); //Ключ для доступа к Yandex Speech Kit
